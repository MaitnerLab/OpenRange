library(testthat)
library(OpenRange)

test_check("OpenRange")
