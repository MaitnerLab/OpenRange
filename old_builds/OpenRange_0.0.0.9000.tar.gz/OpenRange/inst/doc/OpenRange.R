## -----------------------------------------------------------------------------

library(OpenRange)


pcontorta <- OpenRange_load_species(species = "Pinus contorta")

plot(pcontorta[2])


